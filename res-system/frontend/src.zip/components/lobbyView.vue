<template>
  <div style="background-color: white; padding: 20px;">
    <h3>Uniq 영역</h3>
    <p>이 영역은 오른쪽에 표시될 고유한 내용입니다.</p>
    <img alt="img" src="../assets/백경이(hi).png" style="width: 150px;" />
    </div>
</template>

<script>
export default {
  // 컴포넌트 로직
};
</script>

<style scoped>
  .uniq-container {
  height: 100%; /* ✅ 필수 */
}
</style>